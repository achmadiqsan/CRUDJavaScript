# IndexDB_CRUD_Operations
In this project we gonna learn how to create, read, update and delete data from indexdb database using Dexie library.

Well, you gonna learn how to __create, update, read and delete__ data from the local storage indexdb database. 
we are using Dexie.js library to make it possible.

We added minimal code to create this project.

What you can do in this project:
* Create Data and store it in the Indexdb Database
* Update Data
* Read Data
* Delete Data(Manually or bulk)

## Contributor
[akshay kashyap](http://www.youtube.com/c/dailytuition)

### So basically this project is amazing to understand IndexDB Database.
Just Downlaod this project and enjoy...!

